-- phpMyAdmin SQL Dump
-- version 4.1.3
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Jan 27, 2014 at 12:04 AM
-- Server version: 5.6.15
-- PHP Version: 5.3.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `permissions` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `permissions`) VALUES(1, 'Standard user', '');
INSERT INTO `groups` (`id`, `name`, `permissions`) VALUES(2, 'Super Administrator', '{"superadmin": 1,\r\n"admin": 1,\r\n"mod": 1}');
INSERT INTO `groups` (`id`, `name`, `permissions`) VALUES(3, 'Administrator', '{"admin": 1,\r\n"mod": 1}');
INSERT INTO `groups` (`id`, `name`, `permissions`) VALUES(4, 'Moderator', '{"moderator": 1}');

-- --------------------------------------------------------

--
-- Table structure for table `site_data`
--

CREATE TABLE IF NOT EXISTS `site_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `logo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `verify` int(11) NOT NULL DEFAULT '0',
  `verify_email` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `welcome` int(11) NOT NULL DEFAULT '0',
  `welcome_email` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `site_data`
--

INSERT INTO `site_data` (`id`, `name`, `description`, `logo`, `verify`, `verify_email`, `welcome`, `welcome_email`) VALUES(1, 'This is my new site', 'This is my cool new site description.', '', 1, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `salt` binary(32) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `joined` datetime NOT NULL,
  `user_group` int(11) NOT NULL,
  `city` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `image` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=103 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `salt`, `active`, `firstname`, `lastname`, `joined`, `user_group`, `city`, `state`, `country`, `gender`, `dob`, `image`, `reset`, `reset_time`) VALUES(98, 'admin@admin.com', 'd44b7ec3115f307a126114ed218111edcf7249704907efe2c5264bee399edc45', '�����i<�tokg��L�k��䋍���/c��', 0, 'admin', 'admin', '2014-01-17 15:05:28', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `users` (`id`, `username`, `password`, `salt`, `active`, `firstname`, `lastname`, `joined`, `user_group`, `city`, `state`, `country`, `gender`, `dob`, `image`, `reset`, `reset_time`) VALUES(99, 'sfraise77@gmail.com', '9ec6db67efc6253f80650d6316bf75db0ec46be98d080c646d80252dd74a70d9', '����l�݂�v�Q��[�k�F�b���t��', 0, 'Spencer', 'Fraise', '2014-01-17 16:27:23', 2, 'Baldwin', 'Wisconsin', 'United States', 'Male', NULL, '/images/user_images/99/knucklessleeping_1390359830.jpg', NULL, NULL);
INSERT INTO `users` (`id`, `username`, `password`, `salt`, `active`, `firstname`, `lastname`, `joined`, `user_group`, `city`, `state`, `country`, `gender`, `dob`, `image`, `reset`, `reset_time`) VALUES(100, 'test@test.com', 'e52af07c3e2379f46a2f33e10194744b2005a3279748cea72b6914d02f643a6a', '؟k�]��,�\r�.��_H����/��3ƽ', 0, 'Test', 'User', '2014-01-17 17:03:04', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `users` (`id`, `username`, `password`, `salt`, `active`, `firstname`, `lastname`, `joined`, `user_group`, `city`, `state`, `country`, `gender`, `dob`, `image`, `reset`, `reset_time`) VALUES(101, 'test4@test4.com', '0c3bd02d589c0d70ee8763963a8f37e7ba28bf9cea1e6c48036661db8c762da3', '�#jǉ/O�1}LF�R�:D���Ъ]�����', 0, 'Test4', 'User4', '2014-01-21 17:28:34', 1, 'Baldwin', 'Wisconsin', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `users` (`id`, `username`, `password`, `salt`, `active`, `firstname`, `lastname`, `joined`, `user_group`, `city`, `state`, `country`, `gender`, `dob`, `image`, `reset`, `reset_time`) VALUES(102, 'newtest@newtest.com', '639efc3846c37ad576f5aec1426de6196e7599c236078f22f9a5895c749b6333', 'T���"�\rF�چ	�����5�u���jw௷2\0', 0, 'newtest', 'newuser', '2014-01-25 18:01:53', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_session`
--

CREATE TABLE IF NOT EXISTS `users_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `hash` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
